"""Multiplier maps lambda(t, s) on one window for classical, frequency-adjusted, Newton (tangent), exact (secant)
and learned multipliers, at the first two iterations; relative L2 distance of each map to the exact one."""
from evalcore import *
torch.set_num_threads(1)
GLx, GLw = np.polynomial.legendre.leggauss(8); GLx = torch.tensor((GLx + 1) / 2); GLw = torch.tensor(GLw / 2)


def secant(prob, grid, U, V, Ur, Vr, p):
    B, M = U.shape; t = grid.tf[None].expand(B, M); pp = p[:, None].expand(B, M)
    a0 = 0; a1 = 0
    for x, w in zip(GLx, GLw):
        a0 = a0 + w * prob.fu(t, Ur + x * (U - Ur), Vr + x * (V - Vr), pp)
        a1 = a1 + w * prob.fv(t, Ur + x * (U - Ur), Vr + x * (V - Vr), pp)
    return a0, a1


out = {}
for name, path, pval in [("duffing", "gen_duffing_H2.00_K4_m2_classical_jri_ph1_s0.pt", 2.5),
                         ("vdp", "gen_vdp_H2.00_K4_m2_classical_jri_ph1_s0.pt", 2.5)]:
    gen, a = load_gen(path)
    prob = PROBLEMS[name](); grid = Grid(a["H"], a["N"]); gen.grid = grid; gen.prob = prob
    p = torch.tensor([pval]); Ur, Vr = reference(prob, grid, [pval])
    U, V = initial_guess(prob, grid, p); Acc = -U
    maps = {}
    with torch.no_grad():
        for n in range(2):
            R = residual_fine(prob, grid, U, V, Acc, p)
            gens = {}
            gens["classical"] = (torch.ones(grid.M), torch.zeros(grid.M), None, None, None)
            c = float(prob.omega_fa(p)[0] ** 2)
            gens["freqadj"] = (torch.full((grid.M,), c), torch.zeros(grid.M), None, None, None)
            gens["newton"] = (prob.fu(None, U, V, p[:, None])[0], prob.fv(None, U, V, p[:, None])[0], None, None, None)
            s0, s1 = secant(prob, grid, U, V, Ur, Vr, p)
            gens["secant"] = (s0[0], s1[0], None, None, None)
            a0, a1, b, q, P = gen(U, V, p, R, n)
            gens["learned"] = (a0[0], a1[0], b[0], q[0], P)
            for k, (g0, g1, gb, gq, gP) in gens.items():
                Pi = transition_nodes(grid, g0, g1, gb, gq, gP)
                tt, lam = multiplier_matrix(grid, Pi, stride=2)
                maps[f"{k}_n{n}"] = lam.numpy()
            # advance with the learned multiplier (the NODE-VIM path)
            U, V, dVn, _ = vim_step(prob, grid, U, V, p, a0, a1, b, q, P, return_all=True); Acc = acc_fine(dVn)
    ref = {n: maps[f"secant_n{n}"] for n in range(2)}
    dist = {}
    for k in maps:
        n = int(k[-1]); m = ~np.isnan(ref[n])
        dist[k] = float(np.sqrt(np.nansum((maps[k][m] - ref[n][m]) ** 2) / np.nansum(ref[n][m] ** 2)))
    out[name] = dict(dist=dist, p=pval)
    np.savez_compressed(f"lam_{name}.npz", t=tt.numpy(), **maps)
    print(name, {k: round(v, 3) for k, v in dist.items()})
json.dump(out, open("lambda_maps.json", "w"))
