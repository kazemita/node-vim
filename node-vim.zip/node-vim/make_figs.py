"""All figures of the paper from saved results. usage: python make_figs.py [fig ...]"""
import sys, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, TwoSlopeNorm

os.makedirs("paper2/figures", exist_ok=True)
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
                     "mathtext.fontset": "cm"})
COL = dict(classical="#9e9e9e", freqadj="#e08b3a", newton="#333333", anderson="#8e6bbf", learned="#7fb2e5",
           hybrid1="#2f6db5", hybrid2="#5b7fb0", adapt="#0b2a5c", hybrid3="#4f86c6", secant="#2a9d8f", oracle="#c0392b")
LAB = dict(classical="classical VIM", freqadj="frequency-adjusted VIM", newton="Newton (quasilinearisation)",
           anderson="Anderson-accelerated VIM", learned="learned multiplier only", hybrid1="NODE-VIM ($k_L=1$)",
           hybrid2="NODE-VIM (fixed $k_L=2$)", adapt="NODE-VIM", hybrid3="NODE-VIM ($k_L=3$)", secant="secant (exact) multiplier")
PLAB = {"duffing": r"amplitude $A$", "vdp": r"$\mu$", "pendulum": r"$\theta_0$"}
PTIT = {"duffing": "Duffing oscillator", "vdp": "van der Pol oscillator", "pendulum": "pendulum"}
PRANGE = {"duffing": (0.5, 3.0), "vdp": (0.2, 3.0), "pendulum": (0.3, 3.0)}


def save(fig, name):
    for ax in fig.axes:                       # rasterise filled contours in the PDF (vector text and lines stay)
        for c in ax.collections:
            if getattr(c, "filled", False):
                c.set_rasterized(True)
    fig.savefig(f"paper2/figures/{name}.pdf", dpi=220); fig.savefig(f"paper2/figures/{name}.png", dpi=150)
    plt.close(fig); print("saved", name)


def logerr(E, floor=1e-12, cap=1e2):
    E = np.nan_to_num(np.asarray(E, float), nan=cap, posinf=cap)
    return np.log10(np.clip(E, floor, cap))


# ------------------------------------------------------------------------------------------------
def fig_single_contours():
    """error after k = 1, 2, 3 iterations on one window, over (t, p): rows = methods, cols = k (Duffing)
    and k = 3 for van der Pol and the pendulum."""
    for prob in ["duffing", "vdp", "pendulum"]:
        if not os.path.exists(f"sw_{prob}.npz"): continue
        d = np.load(f"sw_{prob}.npz"); t, ps = d["t"], d["ps"]
        meths = ["classical", "freqadj", "newton", "adapt"]
        fig, axes = plt.subplots(len(meths), 3, figsize=(10, 9.2), sharex=True, sharey=True)
        lev = np.arange(-10, 2.01, 1.0)
        for i, m in enumerate(meths):
            for j, k in enumerate((1, 2, 3)):
                ax = axes[i, j]
                Z = logerr(d[f"{m}_k{k}"])
                cs = ax.contourf(t, ps, Z, levels=lev, cmap="magma_r", extend="both")
                ax.contour(t, ps, Z, levels=[-3], colors="w", linewidths=1.0)
                ax.axhline(PRANGE[prob][1], color="w", lw=0.6, ls=":")
                if i == 0: ax.set_title(f"after {k} iteration{'s' if k > 1 else ''}", fontsize=9.5)
                if j == 0: ax.set_ylabel(f"{LAB[m]}\n{PLAB[prob]}", fontsize=8.5)
                if i == len(meths) - 1: ax.set_xlabel("$t$")
        cb = fig.colorbar(cs, ax=axes, shrink=0.6, pad=0.02)
        cb.set_label(r"$\log_{10}|u_k(t)-u^\ast(t)|$")
        fig.suptitle(f"{PTIT[prob]}: error of the $k$-th VIM iterate on one window (white line: error $=10^{{-3}}$; "
                     f"dotted: end of training range)", fontsize=9.5)
        save(fig, f"single_contours_{prob}")


def fig_solution_contours():
    """long-time multistage: solution u(t; p) from NODE-VIM, and error fields of NODE-VIM, Newton, classical."""
    probs = [p for p in ["duffing", "vdp", "pendulum"] if os.path.exists(f"ms_{p}.npz")]
    fig, axes = plt.subplots(len(probs), 4, figsize=(13, 3.0 * len(probs)), squeeze=False)
    for r, prob in enumerate(probs):
        d = np.load(f"ms_{prob}.npz"); t, ps = d["t"], d["ps"]
        U = np.where(d["tol_adapt_err"] < 1e-2, d["tol_adapt_U"], np.nan)      # blank where NODE-VIM failed
        vmax = np.nanmax(np.abs(d["U"]))
        ax = axes[r, 0]
        ax.set_facecolor("0.85")
        cs = ax.contourf(t, ps, U, levels=np.linspace(-vmax, vmax, 41), cmap="RdBu_r", extend="both")
        ax.contour(t, ps, U, levels=[0.0], colors="k", linewidths=0.35)
        fig.colorbar(cs, ax=ax, pad=0.01).set_label("$u(t;p)$")
        ax.set_title(f"{PTIT[prob]}: NODE-VIM solution", fontsize=9.5); ax.set_ylabel(PLAB[prob]); ax.set_xlabel("$t$")
        for c, m in enumerate(["adapt", "newton", "classical"]):
            ax = axes[r, c + 1]
            Z = logerr(d[f"tol_{m}_err"], cap=1e1)
            cs = ax.contourf(t, ps, Z, levels=np.arange(-10, 1.01, 1.0), cmap="magma_r", extend="both")
            ax.axhline(PRANGE[prob][1], color="w", lw=0.6, ls=":")
            ax.set_title(f"error, {LAB[m]}", fontsize=9.5); ax.set_xlabel("$t$")
            if c == 2: fig.colorbar(cs, ax=ax, pad=0.01).set_label(r"$\log_{10}|u-u^\ast|$")
    fig.tight_layout()
    save(fig, "solution_contours")


def fig_iteration_fields():
    """VIM iterations needed per window (tolerance mode) over (window, p): Newton vs NODE-VIM."""
    probs = [p for p in ["duffing", "vdp", "pendulum"] if os.path.exists(f"ms_{p}.npz")]
    fig, axes = plt.subplots(len(probs), 2, figsize=(9, 3.0 * len(probs)), squeeze=False, constrained_layout=True)
    for r, prob in enumerate(probs):
        d = np.load(f"ms_{prob}.npz"); ps = d["ps"]; ev = json.load(open(f"eval_{prob}.json"))
        Hw = ev["H"]
        for c, m in enumerate(["newton", "adapt"]):
            it = d[f"tol_{m}_it"].astype(float)
            err = d[f"tol_{m}_err"]
            nw = it.shape[1]
            # mark windows after divergence
            npw = (err.shape[1] - 1) // nw
            div = np.array([[err[i, w * npw:(w + 1) * npw + 1].max() > 1e-3 for w in range(nw)] for i in range(len(ps))])
            it = np.where(div, np.nan, it)
            ax = axes[r, c]
            im = ax.imshow(it, aspect="auto", origin="lower", cmap="viridis", vmin=1, vmax=12,
                           extent=[0, nw * Hw, ps[0], ps[-1]], interpolation="nearest")
            ax.set_title(f"{PTIT[prob]}: {LAB[m]}", fontsize=9.5)
            if r == len(probs) - 1: ax.set_xlabel("$t$ (window start)")
            if c == 0: ax.set_ylabel(PLAB[prob])
            ax.axhline(PRANGE[prob][1], color="w", lw=0.6, ls=":")
        fig.colorbar(im, ax=axes[r, :], pad=0.01).set_label("iterations per window")
    save(fig, "iteration_fields")


def fig_iters_vs_p():
    probs = [p for p in ["duffing", "vdp", "pendulum"] if os.path.exists(f"eval_{p}.json")]
    fig, axes = plt.subplots(1, len(probs), figsize=(4.2 * len(probs), 3.3), squeeze=False)
    for c, prob in enumerate(probs):
        ev = json.load(open(f"eval_{prob}.json")); ps = np.array(ev["ps"])
        ax = axes[0, c]
        for m in ["classical", "freqadj", "anderson", "newton", "learned", "adapt"]:
            it = np.array(ev["iters_1e-06"][m], float); it[it < 0] = np.nan
            mm = m
            ax.plot(ps, it, color=COL[mm], lw=1.8 if m == "adapt" else 1.2, label=LAB[mm],
                    ls="--" if m in ("classical", "anderson") else "-")
        ax.axvspan(PRANGE[prob][1], ps[-1], color="0.92", lw=0, zorder=0)
        ax.set_title(PTIT[prob], fontsize=9.5); ax.set_xlabel(PLAB[prob]); ax.set_ylim(0, 12.5)
        if c == 0: ax.set_ylabel("iterations to $10^{-6}$ (one window)")
    axes[0, 0].legend(fontsize=7.2, loc="upper left")
    fig.tight_layout(); save(fig, "iters_vs_p")


def fig_validation():
    V = json.load(open("validate.json"))
    fig, axes = plt.subplots(1, 4, figsize=(15, 3.4))
    ax = axes[0]; A = np.array(V["V1"]["ps"])
    for m, lab in [("classical", "classical"), ("freqadj", "frequency-adjusted"), ("newton", "Newton (tangent)"),
                   ("learned_m2", "learned"), ("secant", "secant (Thm. 2)")]:
        c = COL.get(m, COL["adapt"]) if m != "learned_m2" else COL["adapt"]
        ax.semilogy(A, np.clip(np.nan_to_num(V["V1"]["err_after_one_step"][m], nan=1e30, posinf=1e30), 1e-12, 1e30), color=c, label=lab, lw=1.5)
    ax.set_xlabel("amplitude $A$"); ax.set_ylabel("$\\|u_1-u^\\ast\\|_\\infty$")
    ax.set_title("(a) error after one VIM step", fontsize=9.5); ax.legend(fontsize=7)
    ax = axes[1]; A = np.array(V["V3"]["A"])
    for m, c in (("classical", COL["classical"]), ("freqadj", COL["freqadj"])):
        ax.loglog(A, V["V3"]["horizon"][m], "o-", color=c, ms=3, label=f"$H$, {LAB[m].split(' VIM')[0]} (Thm. 4)")
    for m, ls in (("classical", "--"), ("newton", ":"), ("learned", "-")):
        c = COL["adapt"] if m == "learned" else COL[m]
        ax.loglog(A, V["V3"]["front"][m][2], ls, color=c, lw=1.4, label=f"front after 8 its, {m}")
    Ag = np.linspace(1.5, 4, 10); ax.loglog(Ag, 1.1 / Ag ** 2, color="k", lw=0.6)
    ax.text(2.6, 0.16, "slope $-2$", fontsize=7.5)
    from matplotlib.ticker import FixedLocator, NullLocator, FormatStrFormatter
    ax.xaxis.set_major_locator(FixedLocator([0.5, 1, 2, 4])); ax.xaxis.set_minor_locator(NullLocator())
    ax.xaxis.set_major_formatter(FormatStrFormatter("%g"))
    ax.set_xlabel("amplitude $A$"); ax.set_ylabel("time"); ax.set_title("(b) horizon and accuracy front", fontsize=9.5)
    ax.legend(fontsize=6.5)
    ax = axes[2]
    for m in ["classical", "freqadj", "newton", "learned", "adapt"]:
        e = np.array(V["V4"][m])[:, 1]
        e = np.clip(np.nan_to_num(e, nan=1e30, posinf=1e30), 1e-12, 1e30)
        ax.semilogy(np.arange(len(e)), e, "o-", ms=3, color=COL[m], label=LAB[m])
    ax.set_xlabel("iteration $n$"); ax.set_ylabel("$\\|u_n-u^\\ast\\|_\\infty$")
    ax.set_title("(c) convergence at $A=2.5$", fontsize=9.5); ax.legend(fontsize=6.8)
    ax = axes[3]
    for r in V["V5"]:
        ax.semilogy(np.clip(np.nan_to_num(r["curve"], nan=1e30, posinf=1e30), 1e-12, 1e30), color=COL["learned"], lw=0.8, alpha=0.8)
    ax.set_xlabel("iteration $n$"); ax.set_ylabel("median error (8 problems)")
    ax.set_title("(d) untrained random generators (Thm. 3)", fontsize=9.5); ax.set_ylim(1e-12, 1e30)
    fig.tight_layout(); save(fig, "validation")


def fig_secant_curves():
    V = json.load(open("validate.json"))["V2"]
    t = np.array(V["t"]); c = V["curves"]
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.2))
    ax = axes[0]
    ax.plot(t, c["ustar"], color="k", lw=1.5, label="$u^\\ast$"); ax.plot(t, c["u0"], color=COL["classical"], ls="--", label="$u_0$")
    ax.set_xlabel("$s$"); ax.set_title(f"(a) Duffing, $A={V['A_curve']}$: iterate and solution", fontsize=9.5); ax.legend(fontsize=7.5)
    ax = axes[1]
    ax.plot(t, c["secant"], color=COL["secant"], lw=2, label="secant $\\bar a_0$ (exact multiplier)")
    ax.plot(t, c["newton"], color=COL["newton"], lw=1.2, label="tangent $f_u(u_0)$ (Newton)")
    ax.axhline(1.0, color=COL["classical"], ls="--", lw=1, label="classical $\\omega_0^2$")
    ax.axhline(c["freqadj"], color=COL["freqadj"], ls="--", lw=1, label="frequency-adjusted $\\Omega^2$")
    ax.plot(t, c["learned_m2"], color=COL["adapt"], lw=1.4, label="learned $a_0$ ($m=2$)")
    ax.set_xlabel("$s$"); ax.set_title("(b) coefficient $a_0(s)$ of the multiplier dynamic, first iteration", fontsize=9.5)
    ax.legend(fontsize=7)
    fig.tight_layout(); save(fig, "secant_curves")


def fig_lambda_maps():
    for name in ["duffing", "vdp"]:
        if not os.path.exists(f"lam_{name}.npz"): continue
        d = np.load(f"lam_{name}.npz"); t = d["t"]; dist = json.load(open("lambda_maps.json"))[name]
        keys = ["classical", "freqadj", "newton", "secant", "learned"]
        tit = dict(classical="classical", freqadj="frequency-adjusted" if name == "duffing" else "exact-frequency",
                   newton="Newton (tangent)", secant="exact (secant, Thm. 2)", learned="learned (NODE)")
        fig, axes = plt.subplots(2, 5, figsize=(12.5, 5.4), sharex=True, sharey=True)
        vm = np.ceil(10 * np.nanmax(np.abs(d["secant_n0"]))) / 10
        for r in range(2):
            for c, k in enumerate(keys):
                ax = axes[r, c]; L = d[f"{k}_n{r}"]
                cs = ax.contourf(t, t, L, levels=np.linspace(-vm, vm, 31), cmap="PuOr_r", extend="both")
                ax.contour(t, t, L, levels=[0], colors="k", linewidths=0.4)
                dd = dist["dist"][f"{k}_n{r}"]
                ax.set_title(f"{tit[k]}" + (f"\nrel. dist. to exact: {dd:.2f}" if k != "secant" else "\n(reference)"), fontsize=8.5)
                if c == 0: ax.set_ylabel(f"iteration {r}\n$t$")
                if r == 1: ax.set_xlabel("$s$")
        cb = fig.colorbar(cs, ax=axes, shrink=0.7, pad=0.01, ticks=np.linspace(-vm, vm, 5)); cb.set_label(r"$\lambda(t,s)$")
        ptxt = {"duffing": f"Duffing, $A={dist['p']}$", "vdp": f"van der Pol, $\\mu={dist['p']}$"}[name]
        fig.suptitle(f"Lagrange multipliers $\\lambda(t,s)$ on one window ({ptxt}); upper triangle $s>t$ is not used", fontsize=9.5)
        save(fig, f"lambda_maps_{name}")


def _period(t, u):
    up = t[1:][(u[:-1] < 0) & (u[1:] >= 0)]
    if len(up) < 2: return np.nan
    # linear interpolation of the crossings
    idx = np.where((u[:-1] < 0) & (u[1:] >= 0))[0]
    tc = t[idx] - u[idx] * (t[idx + 1] - t[idx]) / (u[idx + 1] - u[idx])
    return np.mean(np.diff(tc))


def fig_period():
    probs = [p for p in ["duffing", "vdp", "pendulum"] if os.path.exists(f"ms_{p}.npz")]
    fig, axes = plt.subplots(2, len(probs), figsize=(4.3 * len(probs), 5.8), squeeze=False)
    res = {}
    MK = dict(classical=("x", 4, 1.0), freqadj=("+", 5, 1.0), newton=("o", 2.2, 1.0), adapt=("o", 6, 0.0))
    for c, prob in enumerate(probs):
        d = np.load(f"ms_{prob}.npz"); t, ps = d["t"], d["ps"]
        Pref = np.array([_period(t, u) for u in d["U"]])
        res[prob] = {"ps": ps.tolist(), "ref": Pref.tolist()}
        ax = axes[0, c]
        ax.plot(ps, Pref, color="k", lw=1.0, label="reference", zorder=1)
        for m in ["classical", "freqadj", "newton", "adapt"]:
            ok = d[f"tol_{m}_err"].max(1) < 1e-2
            P = np.array([_period(t, u) for u in d[f"tol_{m}_U"]]); P[~ok] = np.nan
            res[prob][f"tol_{m}"] = P.tolist(); res[prob][f"tol_{m}_cover"] = float(ok[ps <= PRANGE[prob][1] + 1e-9].mean())
            if m == "adapt":
                ax.plot(ps, P, "o", ms=4.5, color=COL[m], mfc="none", mew=1.0, label=LAB[m] + " (converged)", zorder=2)
            k = ["classical", "freqadj", "newton", "adapt"].index(m)
            yb = 0.05 + 0.055 * k; trans = ax.get_xaxis_transform()
            ax.plot(ps, np.where(ok, yb, np.nan), "-", color=COL[m], lw=3.2, transform=trans, solid_capstyle="butt")
            ax.text(ps[-1] + 0.02 * (ps[-1] - ps[0]), yb, {"classical": "cl", "freqadj": "fa", "newton": "N", "adapt": "NV"}[m],
                    transform=trans, fontsize=6.5, va="center", color=COL[m])
        ax.axvspan(PRANGE[prob][1], ps[-1], color="0.92", lw=0, zorder=0)
        lo, hi = np.nanmin(Pref), np.nanmax(Pref); ax.set_ylim(lo - 0.32 * (hi - lo), hi + 0.05 * (hi - lo))
        ax.set_title(f"{PTIT[prob]}: period; bars = converged range", fontsize=9.5)
        if c == 0: ax.set_ylabel("period")
        ax = axes[1, c]
        for m in ["classical", "freqadj", "newton", "adapt"]:
            err = d[f"K3_{m}_err"].max(1)
            P = np.array([_period(t, u) for u in d[f"K3_{m}_U"]])
            rel = np.abs(P - Pref) / Pref; bad = (err > 0.5) | ~np.isfinite(rel)
            res[prob][f"K3_{m}"] = np.where(bad, np.nan, rel).tolist()
            ax.semilogy(ps, np.where(bad, np.nan, np.maximum(rel, 1e-7)), "-", color=COL[m], lw=1.6 if m == "adapt" else 1.0)
            ax.semilogy(ps[bad], np.full(bad.sum(), 3.0), "|", color=COL[m], ms=6 + 2 * ["classical", "freqadj", "newton", "adapt"].index(m))
        ax.axhline(1.0, color="0.6", lw=0.5); ax.text(ps[0], 4.5, "failed (marks)", fontsize=7, color="0.4")
        ax.axvspan(PRANGE[prob][1], ps[-1], color="0.92", lw=0, zorder=0)
        ax.set_ylim(1e-7, 20); ax.set_xlabel(PLAB[prob])
        ax.set_title("relative period error, 3 iterations per window", fontsize=9.5)
        if c == 0: ax.set_ylabel("$|P-P^\\ast|/P^\\ast$")
    axes[0, 0].legend(fontsize=7)
    fig.tight_layout(); save(fig, "period")
    json.dump(res, open("period.json", "w"))


def fig_phase():
    cases = [("vdp", 2.5), ("duffing", 2.5), ("pendulum", 2.9)]
    cases = [c for c in cases if os.path.exists(f"ms_{c[0]}.npz")]
    fig, axes = plt.subplots(2, len(cases), figsize=(4.4 * len(cases), 6.4), squeeze=False)
    for c, (prob, pv) in enumerate(cases):
        d = np.load(f"ms_{prob}.npz"); t, ps = d["t"], d["ps"]; i = int(np.argmin(np.abs(ps - pv)))
        ax = axes[0, c]
        ax.plot(d["U"][i], d["V"][i], color="k", lw=2.4, label="reference")
        for m, ls in (("classical", "--"), ("newton", ":"), ("adapt", "-")):
            U, V = d[f"K3_{m}_U"][i], d[f"K3_{m}_V"][i]
            ok = np.abs(U) < 50
            ax.plot(np.where(ok, U, np.nan), np.where(ok, V, np.nan), ls, color=COL[m], lw=1.2,
                    label=LAB[m])
        lim = 1.3 * np.abs(d["U"][i]).max(); limv = 1.3 * np.abs(d["V"][i]).max()
        ax.set_xlim(-lim, lim); ax.set_ylim(-limv, limv)
        ax.set_title(f"{PTIT[prob]}, {PLAB[prob]}$={ps[i]:.2f}$: phase plane", fontsize=9)
        ax.set_xlabel("$u$"); ax.set_ylabel("$u'$")
        ax = axes[1, c]
        ax.plot(t, d["U"][i], color="k", lw=2.2, label="reference")
        for m, ls in (("classical", "--"), ("newton", ":"), ("adapt", "-")):
            U = d[f"K3_{m}_U"][i]; ok = np.abs(U) < 50
            ax.plot(t, np.where(ok, U, np.nan), ls, color=COL[m], lw=1.1)
        ax.set_ylim(-lim, lim); ax.set_xlabel("$t$"); ax.set_ylabel("$u(t)$")
        ax.set_title("time history (3 iterations per window)", fontsize=9)
    axes[0, 0].legend(fontsize=7, loc="upper left")
    fig.tight_layout(); save(fig, "phase")


def fig_training():
    import glob
    fig, ax = plt.subplots(1, 1, figsize=(5.2, 3.0))
    for prob, f, c in [("duffing", "trainlog_duffing_H2.00_K4_m2_classical_jri_ph1_s0.json", "#0b2a5c"),
                       ("vdp", "trainlog_vdp_H2.00_K4_m2_classical_jri_ph1_s0.json", "#e08b3a"),
                       ("pendulum", "trainlog_pendulum_H6.00_K4_m2_classical_jri_ph1_s0.json", "#2a9d8f")]:
        L = np.array(json.load(open(f))["log"]); k = 25
        sm = np.convolve(L, np.ones(k) / k, mode="valid")
        ax.plot(L, color=c, alpha=0.18, lw=0.6); ax.plot(np.arange(k - 1, len(L)), sm, color=c, lw=1.5, label=PTIT[prob])
    ax.set_xlabel("training step"); ax.set_ylabel(r"$\frac{1}{K}\sum_k \log \overline{R[u_k]^2}$")
    ax.legend(fontsize=7.5); ax.set_title("physics-only training loss (log mean-square defect)", fontsize=9)
    fig.tight_layout(); save(fig, "training")


if __name__ == "__main__":
    which = sys.argv[1:] or ["single", "solution", "iterfields", "itersp", "validation", "secant", "lam", "period", "phase"]
    F = dict(single=fig_single_contours, solution=fig_solution_contours, iterfields=fig_iteration_fields,
             itersp=fig_iters_vs_p, validation=fig_validation, secant=fig_secant_curves, lam=fig_lambda_maps,
             period=fig_period, phase=fig_phase, training=fig_training)
    for w in which:
        F[w]()


