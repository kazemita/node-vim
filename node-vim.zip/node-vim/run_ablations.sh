#!/bin/bash
# Duffing ablation variants of the paper (Table: ablations). Each run takes 4-8 minutes on one CPU core.
run() { python train.py --prob duffing --H 2.0 --N 200 --K ${K:-4} --steps 1000 --phase 1 "$@"; }
run --feats jri --m 2                    # main model
run --feats jri --m 0                    # no latent memory
run --feats jri --m 4
run --feats j   --m 2
run --feats jr  --m 2
run --feats ji  --m 2
run --feats ri  --m 2
run --feats jri --m 2 --anchor newton
run --feats jri --m 2 --anchor gated
run --feats jri --m 2 --seed 1
run --feats jri --m 2 --seed 2
K=2 run --feats jri --m 2
run --feats sjri --m 2 --Hmin 0.5        # random window lengths in [0.5, 2]
python ablate_eval.py
