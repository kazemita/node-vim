"""Adds the adaptive NODE-VIM curve to V4 of validate.json (same setting as validate.py)."""
from evalcore import *
import json
V = json.load(open("validate.json"))
prob = Duffing()

grid = Grid(2.0, 400)
gen2, _ = load_gen("gen_duffing_H2.00_K4_m2_classical_jri_ph1_s0.pt", prob, grid)
with torch.no_grad():
    pA = torch.tensor([1.5, 2.5]); UrA, _ = reference(prob, grid, [1.5, 2.5])
    Hh = run("adapt", prob, grid, pA, 10, gen2)
    E = torch.stack([(U - UrA).abs().amax(1) for U, V_ in Hh]).numpy()
V["V4"]["adapt"] = E.tolist()
print(E[:, 1])
json.dump(V, open("validate.json", "w"))
