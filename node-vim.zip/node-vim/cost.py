"""Wall time of one iteration: classical / Newton / learned (generator + augmented dynamic). Ratios are what matter."""
import time
from evalcore import *
torch.set_num_threads(1)
out = {}
for name, f in [("duffing", "gen_duffing_H2.00_K4_m2_classical_jri_ph1_s0.pt"), ("vdp", "gen_vdp_H2.00_K4_m2_classical_jri_ph1_s0.pt"),
                ("pendulum", "gen_pendulum_H6.00_K4_m2_classical_jri_ph1_s0.pt")]:
    prob = PROBLEMS[name](); a = torch.load(f, weights_only=False)["args"]; grid = Grid(a["H"], a["N"])
    gen, _ = load_gen(f, prob, grid)
    p = torch.tensor(np.linspace(a["plo"], a["phi"], 64)); U, V = initial_guess(prob, grid, p); Acc = -U
    T = {}
    with torch.no_grad():
        for meth in ["classical", "newton", "learned"]:
            ts = []
            for r in range(25):
                t0 = time.perf_counter()
                if meth == "learned":
                    R = residual_fine(prob, grid, U, V, Acc, p); a0, a1, b, q, P = gen(U, V, p, R, 0)
                    vim_step(prob, grid, U, V, p, a0, a1, b, q, P, return_all=True)
                else:
                    a0, a1 = coeffs_fixed(meth, prob, grid, U, V, p); vim_step(prob, grid, U, V, p, a0, a1, return_all=True)
                ts.append(time.perf_counter() - t0)
            T[meth] = float(np.median(ts[5:]))
    tl = json.load(open(f.replace("gen_", "trainlog_").replace(".pt", ".json")))
    nparam = sum(x.numel() for x in gen.parameters())
    out[name] = dict(times=T, ratio_learned_newton=T["learned"] / T["newton"], train_time=tl["train_time"], nparam=nparam, N=a["N"], B=64)
    print(name, {k: f"{v*1e3:.1f} ms" for k, v in T.items()}, "ratio", round(T["learned"] / T["newton"], 2), "train", round(tl["train_time"]), "s", "params", nparam)
json.dump(out, open("cost.json", "w"), indent=1)
