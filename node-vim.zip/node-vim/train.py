"""Train a neural-ODE multiplier generator (physics-only loss) on windows of a parametric oscillator family.
usage: python train.py --prob duffing --H 3.14159 --N 300 --plo 0.5 --phi 3.0 --K 4 --steps 600 --tag x
Windows start at random phases of the reference trajectory family (--phase 1) or at t=0 (--phase 0)."""
import argparse
from osc import *

ap = argparse.ArgumentParser()
ap.add_argument("--prob", default="duffing")
ap.add_argument("--H", type=float, default=math.pi)
ap.add_argument("--N", type=int, default=300)
ap.add_argument("--plo", type=float, default=0.5)
ap.add_argument("--phi", type=float, default=3.0)
ap.add_argument("--K", type=int, default=4)
ap.add_argument("--steps", type=int, default=600)
ap.add_argument("--batch", type=int, default=32)
ap.add_argument("--m", type=int, default=0)
ap.add_argument("--anchor", default="classical")
ap.add_argument("--feats", default="jri")
ap.add_argument("--phase", type=int, default=1)
ap.add_argument("--lr", type=float, default=2e-3)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--tag", default="")
ap.add_argument("--Hmin", type=float, default=0.0)   # > 0: window length drawn from U[Hmin, H] at every step
args, _ = ap.parse_known_args()
torch.set_num_threads(1)


class TrajectoryBank:
    """reference states u*(t; p), v*(t; p) on a (p, t) table, used to draw window initial conditions."""
    def __init__(self, prob, p_lo, p_hi, n_p=121, t_max=40.0, n_t=4001):
        self.prob = prob
        self.ps = np.linspace(p_lo, p_hi, n_p); self.ts = np.linspace(0, t_max, n_t)
        U = np.zeros((n_p, n_t)); V = np.zeros_like(U)
        for i, pi in enumerate(self.ps):
            u0, v0 = [float(x) for x in prob.ic(torch.tensor([pi]))]
            s = solve_ivp(lambda t, y: [y[1], -prob.f_np(t, y[0], y[1], pi)], (0, t_max), [u0, v0],
                          method="DOP853", rtol=1e-11, atol=1e-11, t_eval=self.ts)
            U[i], V[i] = s.y
        self.U, self.V = U, V

    def sample(self, B, rng, phase=True):
        ip = rng.integers(0, len(self.ps), B)
        it = rng.integers(0, len(self.ts), B) if phase else np.zeros(B, int)
        return (torch.tensor(self.ps[ip]), torch.tensor(self.U[ip, it]), torch.tensor(self.V[ip, it]))


def guess_from_state(prob, grid, u0, v0):
    w = prob.omega0; t = grid.tf[None]
    U = u0[:, None] * torch.cos(w * t) + v0[:, None] / w * torch.sin(w * t)
    V = -u0[:, None] * w * torch.sin(w * t) + v0[:, None] * torch.cos(w * t)
    return U, V


class WindowProblem:
    """the oscillator with initial condition overridden by the window state (u0, v0)."""
    def __init__(self, prob): self.prob = prob; self.u0 = None; self.v0 = None
    def __getattr__(self, k): return getattr(self.prob, k)
    def ic(self, p): return self.u0, self.v0


if __name__ == "__main__":
    torch.manual_seed(args.seed); rng = np.random.default_rng(args.seed)
    prob = PROBLEMS[args.prob]()
    grid = Grid(args.H, args.N)
    bank = TrajectoryBank(prob, args.plo, args.phi)
    wp = WindowProblem(prob)
    gen = Generator(wp, grid, (args.plo, args.phi), m=args.m, anchor=args.anchor, feats=args.feats, n_max=args.K)
    opt = torch.optim.Adam(gen.parameters(), lr=args.lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, args.steps)
    tag = args.tag or (f"{args.prob}_H{args.H:.2f}_K{args.K}_m{args.m}_{args.anchor}_{args.feats}_ph{args.phase}_s{args.seed}"
                       + (f"_Hmin{args.Hmin:.2f}" if args.Hmin > 0 else ""))
    log = []; t0 = time.time(); skipped = 0
    for it in range(args.steps):
        p, u0, v0 = bank.sample(args.batch, rng, phase=bool(args.phase))
        if args.Hmin > 0:
            Hs = float(rng.uniform(args.Hmin, args.H))
            grid = Grid(Hs, max(10, int(round(args.N * Hs / args.H))))
            gen.grid = grid
        wp.u0, wp.v0 = u0, v0
        U, V = guess_from_state(prob, grid, u0, v0)
        Acc = -prob.omega0 ** 2 * U
        loss = 0.0
        for k in range(args.K):
            Rf = residual_fine(wp, grid, U, V, Acc, p)
            a0, a1, b, q, P = gen(U, V, p, Rf, k)
            U, V, dVn, _ = vim_step(wp, grid, U, V, p, a0, a1, b, q, P, return_all=True)
            Acc = acc_fine(dVn)
            R = residual_nodes(wp, grid, U, V, dVn, p)
            r2 = torch.nan_to_num(R.pow(2).mean(1), nan=1e300, posinf=1e300).clamp(max=1e300)
            loss = loss + torch.log(r2 + 1e-24).mean() / args.K
        if not torch.isfinite(loss):
            skipped += 1; continue
        opt.zero_grad(); loss.backward()
        gn = torch.nn.utils.clip_grad_norm_(gen.parameters(), 1.0)
        if not torch.isfinite(gn):
            opt.zero_grad(); skipped += 1; sched.step(); continue
        opt.step(); sched.step(); log.append(loss.item())
        if it % 50 == 0 or it == args.steps - 1:
            print(f"{tag} it={it:4d} loss={loss.item():8.3f} skipped={skipped} ({time.time()-t0:5.0f}s)", flush=True)
    torch.save(dict(state=gen.state_dict(), args=vars(args)), f"gen_{tag}.pt")
    json.dump(dict(log=log, train_time=time.time() - t0, args=vars(args)), open(f"trainlog_{tag}.json", "w"))
