"""Schematic: the multiplier as a functional (kernel) and as a dynamic (generator + linear ODE)."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({"font.size": 9, "mathtext.fontset": "cm"})
fig = plt.figure(figsize=(12.5, 4.3))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 12.5); ax.set_ylim(0, 4.3); ax.axis("off")


def box(x, y, w, h, txt, fc="#eef3fa", ec="#0b2a5c", fs=9, lw=1.0):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04,rounding_size=0.08", fc=fc, ec=ec, lw=lw))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=fs)


def arr(x0, y0, x1, y1, txt=None, off=(0, 0.12), color="#333333", ls="-"):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=11, color=color, lw=1.0, linestyle=ls))
    if txt: ax.text((x0 + x1) / 2 + off[0], (y0 + y1) / 2 + off[1], txt, ha="center", va="bottom", fontsize=8, color=color)


# --- functional view (left): kernel picture from the learned Duffing multiplier
d = np.load("lam_duffing.npz"); t = d["t"]; L = d["learned_n0"]
axk = fig.add_axes([0.035, 0.27, 0.17, 0.53])
vm = np.nanmax(np.abs(L))
axk.contourf(t, t, L, levels=np.linspace(-vm, vm, 25), cmap="PuOr_r")
axk.set_xlabel("$s$", labelpad=1); axk.set_ylabel("$t$", labelpad=1); axk.set_xticks([0, 1, 2]); axk.set_yticks([0, 1, 2])
axk.set_title("functional view:\nkernel $\\lambda_\\theta[u_n](t,s)$, $s\\leq t$", fontsize=9)
ax.text(1.4, 0.12, "$u_{n+1}=u_n+\\int_0^t\\lambda\\,R[u_n]\\,ds$\n$O(N^2)$ work and storage", ha="center", fontsize=8.2)

# --- equivalence
ax.text(3.35, 2.45, "Thm. 1", ha="center", fontsize=8.5, color="#2a9d8f", weight="bold")
ax.add_patch(FancyArrowPatch((2.85, 2.2), (3.9, 2.2), arrowstyle="<|-|>", mutation_scale=12, color="#2a9d8f", lw=1.4))
ax.text(3.37, 1.55, "$\\lambda_\\theta(t,s)=$\n$-e_1^{\\top}\\Phi_\\theta(t,s)\\,e_2$", ha="center", fontsize=8.6, color="#2a9d8f")

# --- dynamic view (right)
ax.text(8.0, 4.0, "dynamic view: one VIM iteration = one forward linear solve", ha="center", fontsize=9.5)
box(4.05, 2.75, 1.9, 0.95, "iterate features\n$u_n,\\,u_n',\\,\\hat p$\n$f_u,\\,f_v,\\,\\mathrm{asinh}\\,R[u_n],\\,n/K$", fs=8.2)
box(6.35, 2.75, 1.55, 0.95, "generator\n$g_\\theta$ (MLP, 9.2k par.)\nbounded outputs", fc="#e7f4f2", ec="#2a9d8f", fs=8.2)
box(8.3, 2.75, 2.15, 0.95, "dynamic $A_\\theta(s)$\n$a_0,a_1,\\ b,q\\in\\mathbb{R}^m,\\ P$\nstable latent memory", fs=8.2)
box(10.75, 2.75, 1.6, 0.95, "classical anchor\n$a_0=\\omega_0^2$ at init\n(zero last layer)", fc="#f6f6f6", ec="#888888", fs=7.8)
arr(5.95, 3.22, 6.35, 3.22); arr(7.9, 3.22, 8.3, 3.22); arr(10.75, 3.22, 10.45, 3.22, color="#888888", ls="--")
box(4.05, 1.2, 3.85, 1.05, "$w''+a_1w'+a_0w+b^{\\top}z=-R[u_n]$\n$z'=Pz+q\\,w,\\quad w(0)=w'(0)=0,\\ z(0)=0$\n$u_{n+1}=u_n+w$", fs=8.6)
box(8.3, 1.2, 2.15, 1.05, "RK4 cell maps\n$x_{k+1}=M_kx_k+c_k$\nprefix scan, depth $O(\\log N)$", fs=8.2)
box(10.75, 1.2, 1.6, 1.05, "$u_{n+1}$\n$O(N(2+m)^3)$\nno kernel stored", fc="#eef3fa", fs=8.2)
arr(9.37, 2.75, 9.37, 2.25); arr(7.9, 1.72, 8.3, 1.72); arr(10.45, 1.72, 10.75, 1.72)
arr(6.0, 2.75, 6.0, 2.25)
box(4.05, 0.15, 8.3, 0.72, "NODE-VIM schedule: learned multiplier while $\\max|R[u_n]|>r_{sw}$ (far from $u^\\ast$: closer to the exact secant multiplier, Thm. 2),\n"
    "then the tangent (Newton) multiplier near $u^\\ast$ (quadratic convergence); per parameter value and per window", fc="#fbf3e9", ec="#e08b3a", fs=8.2)
fig.savefig("paper2/figures/schematic.pdf", bbox_inches="tight"); fig.savefig("paper2/figures/schematic.png", dpi=170, bbox_inches="tight")
print("saved")
