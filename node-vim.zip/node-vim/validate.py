"""Numerical validation of the theory on the Duffing oscillator.
V1  exact error identity (Theorem 2) and the one-step-exact secant multiplier
V2  the learned coefficients approach the secant (segment-averaged) Jacobian, not the tangent
V3  horizon of constant multipliers: kappa-based prediction and observed accuracy front vs amplitude
V4  convergence orders (Newton: 2, learned-only: 1, NODE-VIM: 2 after the switch)
V5  untrained random generators converge (Theorem 3)"""
from evalcore import *
torch.set_num_threads(1)
out = {}
prob = Duffing(); eps = prob.eps
GLx, GLw = np.polynomial.legendre.leggauss(8); GLx = torch.tensor((GLx + 1) / 2); GLw = torch.tensor(GLw / 2)


def secant_coeffs(prob, grid, U, V, Ur, Vr, p):
    """segment-averaged Jacobians a0 = int_0^1 f_u(u* + tau d, v* + tau d') dtau (8-point Gauss-Legendre)."""
    B, M = U.shape
    t = grid.tf[None].expand(B, M); pp = p[:, None].expand(B, M)
    a0 = 0; a1 = 0
    for x, w in zip(GLx, GLw):
        uu = Ur + x * (U - Ur); vv = Vr + x * (V - Vr)
        a0 = a0 + w * prob.fu(t, uu, vv, pp); a1 = a1 + w * prob.fv(t, uu, vv, pp)
    return a0, a1


class Forced(Problem):
    """linear test problem d'' + a1 d' + a0 d = S(t), d(0)=d'(0)=0  (f = -S on the fine grid)."""
    def __init__(self, S): self.S = S
    def f(self, t, u, v, p): return -self.S
    def ic(self, p): return torch.zeros_like(p), torch.zeros_like(p)


# ---------------- V1: exact identity and secant oracle ----------------
H, N = 2.0, 400
grid = Grid(H, N)
ps = np.linspace(0.5, 3.0, 26)
p = torch.tensor(ps)
Ur, Vr = reference(prob, grid, ps)
U0, V0 = initial_guess(prob, grid, p)
gen0, _ = load_gen("gen_duffing_H2.00_K4_m0_classical_jri_ph1_s0.pt", prob, grid)
gen2, _ = load_gen("gen_duffing_H2.00_K4_m2_classical_jri_ph1_s0.pt", prob, grid)
res = {}
with torch.no_grad():
    for name in ["classical", "freqadj", "newton", "learned_m0", "learned_m2", "secant"]:
        if name == "secant":
            a0, a1 = secant_coeffs(prob, grid, U0, V0, Ur, Vr, p); b = q = P = None
        elif name.startswith("learned"):
            g = gen0 if name.endswith("m0") else gen2
            Acc = -U0
            a0, a1, b, q, P = g(U0, V0, p, residual_fine(prob, grid, U0, V0, Acc, p), 0)
        else:
            a0, a1 = coeffs_fixed(name, prob, grid, U0, V0, p); b = q = P = None
        U1, V1 = vim_step(prob, grid, U0, V0, p, a0, a1, b, q, P)
        res[name] = (U1 - Ur).abs().amax(1).tolist()
    # identity check for the m=0 learned generator: predicted d1 from L_theta d1 = (a - abar) d0 + (a1 - abar1) d0'
    a0, a1, _, _, _ = gen0(U0, V0, p, residual_fine(prob, grid, U0, V0, -U0, p), 0)
    ab0, ab1 = secant_coeffs(prob, grid, U0, V0, Ur, Vr, p)
    d0, dd0 = U0 - Ur, V0 - Vr
    S = (a0 - ab0) * d0 + (a1 - ab1) * dd0
    fp = Forced(S)
    Z = torch.zeros_like(U0)
    D1, _ = vim_step(fp, grid, Z, Z, p, a0, a1)
    U1, _ = vim_step(prob, grid, U0, V0, p, a0, a1)
    actual = U1 - Ur
    rel = ((D1 - actual).abs().amax(1) / actual.abs().amax(1)).tolist()
out["V1"] = dict(ps=ps.tolist(), err_after_one_step=res, identity_rel_mismatch=rel)
print("V1 error after one step (median over A):", {k: f"{np.median(v):.1e}" for k, v in res.items()})
print("V1 identity relative mismatch: max", f"{max(rel):.1e}")

# ---------------- V2: learned coefficients vs secant target ----------------
dist = {k: [] for k in ["classical", "freqadj", "newton", "learned_m0", "learned_m2"]}
curves = {}
with torch.no_grad():
    for g, gname in ((gen0, "learned_m0"), (gen2, "learned_m2")):
        U, V = U0, V0; Acc = -U0
        for n in range(3):
            ab0, _ = secant_coeffs(prob, grid, U, V, Ur, Vr, p)
            R = residual_fine(prob, grid, U, V, Acc, p)
            a0, a1, b, q, P = g(U, V, p, R, n)
            rms = lambda x: (x - ab0).pow(2).mean(1).sqrt()
            if gname == "learned_m0":
                dist["classical"].append(rms(torch.ones_like(U)).tolist())
                dist["freqadj"].append(rms(prob.omega_fa(p)[:, None].expand_as(U) ** 2).tolist())
                dist["newton"].append(rms(prob.fu(None, U, V, p[:, None])).tolist())
            dist[gname].append(rms(a0).tolist())
            if n == 0:
                i = int(np.argmin(np.abs(ps - 2.5)))
                curves[gname] = a0[i, 0::2].tolist()
                curves["secant"] = ab0[i, 0::2].tolist(); curves["newton"] = prob.fu(None, U, V, None)[i, 0::2].tolist()
                curves["freqadj"] = float(prob.omega_fa(p)[i] ** 2); curves["u0"] = U[i, 0::2].tolist(); curves["ustar"] = Ur[i, 0::2].tolist()
            Un, Vn, dVn, _ = vim_step(prob, grid, U, V, p, a0, a1, b, q, P, return_all=True)
            U, V, Acc = Un, Vn, acc_fine(dVn)
out["V2"] = dict(dist=dist, curves=curves, t=grid.tn.tolist(), A_curve=2.5)
for k, v in dist.items():
    print(f"V2 RMS distance to secant, {k:10s}: " + " ".join(f"n={n}: {np.median(x):.2f}" for n, x in enumerate(v)))

# ---------------- V3: horizons of constant multipliers ----------------
Tl, Nl = 12.0, 2400
gl = Grid(Tl, Nl)
As = np.geomspace(0.5, 4.0, 15)
Ur_l, Vr_l = reference(prob, gl, As)
hor = {"classical": [], "freqadj": []}
for i, A in enumerate(As):
    TA = min(12.0, 6.0 / A ** 2 + 0.5)                     # resolve the horizon: amplitude-adapted grid
    gA = Grid(TA, 1500)
    UA, VA = reference(prob, gA, [A])
    for name, c in (("classical", 1.0), ("freqadj", float(prob.omega_fa(torch.tensor([A]))[0] ** 2))):
        a0 = torch.full((gA.M,), c); a1 = torch.zeros(gA.M)
        Pi = transition_nodes(gA, a0, a1)
        da0 = prob.fu(None, UA[0], VA[0], None) - c
        tk, kap = kappa_curve(gA, Pi, da0, torch.zeros_like(da0), stride=1)
        j = torch.nonzero(kap >= 1.0)
        hor[name].append(float(tk[j[0]]) if len(j) else float("inf"))
# observed accuracy front after k iterations on the long window
front = {}
with torch.no_grad():
    pA = torch.tensor(As)
    for name in ["classical", "freqadj", "newton"]:
        Hh = run(name, prob, gl, pA, 8)
        fr = []
        for k in (2, 4, 8):
            e = torch.nan_to_num((Hh[k][0] - Ur_l).abs(), nan=1e300)[:, 0::2]
            bad = e > 1e-3
            idx = torch.where(bad.any(1), bad.float().argmax(1), torch.full((len(As),), gl.N))
            fr.append(gl.tn[idx].tolist())
        front[name] = fr
    gen2.grid = gl
    Hh = run("learned", prob, gl, pA, 8, gen2)
    fr = []
    for k in (2, 4, 8):
        e = torch.nan_to_num((Hh[k][0] - Ur_l).abs(), nan=1e300)[:, 0::2]
        bad = e > 1e-3
        idx = torch.where(bad.any(1), bad.float().argmax(1), torch.full((len(As),), gl.N))
        fr.append(gl.tn[idx].tolist())
    front["learned"] = fr
    gen2.grid = grid
slopes = {k: float(np.polyfit(np.log(As[As >= 1.5]), np.log(np.array(v)[As >= 1.5]), 1)[0]) for k, v in hor.items()}
slopes.update({f"front8_{k}": float(np.polyfit(np.log(As[As >= 1.5]), np.log(np.array(v[2])[As >= 1.5]), 1)[0]) for k, v in front.items()})
out["V3"] = dict(A=As.tolist(), horizon=hor, slopes=slopes, front=front, front_k=[2, 4, 8])
print("V3 kappa-horizon slopes (A >= 1.5):", {k: round(v, 2) for k, v in slopes.items()})
print("V3 kappa-horizon classical:", [round(x, 2) for x in hor["classical"]])
print("V3 kappa-horizon freqadj:  ", [round(x, 2) for x in hor["freqadj"]])
for k, v in front.items():
    print(f"V3 observed front after 8 its, {k:9s}:", [round(x, 2) for x in v[2]])

# ---------------- V4: convergence orders ----------------
orders = {}
with torch.no_grad():
    pA = torch.tensor([1.5, 2.5])
    UrA, _ = reference(prob, grid, [1.5, 2.5])
    for name in ["newton", "learned", "hybrid2", "classical", "freqadj"]:
        Hh = run(name, prob, grid, pA, 10, gen2)
        E = torch.stack([(U - UrA).abs().amax(1) for U, V in Hh]).numpy()
        orders[name] = E.tolist()
out["V4"] = orders


def est_order(e, lo=1e-9, hi=1e-1):
    o = [np.log(e[k + 1]) / np.log(e[k]) for k in range(len(e) - 1) if lo < e[k + 1] < hi and lo < e[k] < hi and e[k] < 1]
    return float(np.median(o)) if o else float("nan")


for k, v in orders.items():
    e = np.array(v)[:, 0]
    print(f"V4 {k:9s} errors (A=1.5): " + " ".join(f"{x:.0e}" for x in e))

# ---------------- V5: untrained random generators ----------------
rnd = []
with torch.no_grad():
    pA = torch.tensor(np.linspace(0.5, 2.0, 8))
    UrA, _ = reference(prob, grid, pA.numpy())
    for s in range(12):
        torch.manual_seed(500 + s)
        g = Generator(prob, grid, (0.5, 3.0), m=2, feats="jri", n_max=4)
        for prm in g.body.parameters(): prm.normal_(0, 0.5)
        Hh = run("learned", prob, grid, pA, 60, g)
        E = torch.stack([torch.nan_to_num((U - UrA).abs().amax(1), nan=1e300) for U, V in Hh]).numpy()
        rnd.append(dict(conv=int((E[-1] < 1e-6).sum()), peak=float(E.max()), curve=np.median(E, 1).tolist()))
out["V5"] = rnd
print("V5 random generators: converged", sum(r["conv"] for r in rnd), "/", 12 * 8, " peak errors", [f"{r['peak']:.0e}" for r in rnd])
json.dump(out, open("validate.json", "w"))
