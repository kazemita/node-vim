"""LaTeX tables and a numbers file for the manuscript, built from eval_*.json, validate.json, lambda_maps.json."""
import json, numpy as np
PR = {"duffing": (0.5, 3.0), "vdp": (0.2, 3.0), "pendulum": (0.3, 3.0)}
NAMES = dict(classical="classical VIM", freqadj="frequency-adjusted VIM", anderson="Anderson-accelerated VIM",
             newton="Newton (quasilinearisation)", learned="learned multiplier only", hybrid2="NODE-VIM, fixed switch ($k_L=2$)",
             adapt="NODE-VIM (adaptive)")
num = {}
rows1, rows2 = [], []
meths1 = ["classical", "freqadj", "anderson", "newton", "learned", "hybrid2", "adapt"]
meths2 = ["classical", "freqadj", "newton", "learned", "hybrid2", "adapt"]
for prob in ["duffing", "vdp", "pendulum"]:
    E = json.load(open(f"eval_{prob}.json")); ps = np.array(E["ps"]); inr = ps <= PR[prob][1] + 1e-9; ext = ~inr
    num[prob] = {"single": {}, "ms": {}}
    for m in meths1:
        it = np.array(E["iters_1e-06"][m]); ok = it >= 0
        d = dict(median=float(np.median(it[inr & ok])) if (inr & ok).any() else np.nan,
                 max=int(it[inr & ok].max()) if (inr & ok).any() else -1,
                 fail=float(1 - ok[inr].mean()), fail_ext=float(1 - ok[ext].mean()) if ext.any() else np.nan,
                 mean=float(np.mean(it[inr & ok])) if (inr & ok).any() else np.nan)
        num[prob]["single"][m] = d
    for m in meths2:
        T = E["multistage"][f"tol_{m}"]; K = E["multistage"][f"K3_{m}"]
        me = np.nan_to_num(np.array(T["maxerr"], float), nan=1e300); ti = np.array(T["total_iters"], float)
        mk = np.nan_to_num(np.array(K["maxerr"], float), nan=1e300)
        ok = me < 1e-4
        num[prob]["ms"][m] = dict(succ=float(ok[inr].mean()), succ_ext=float(ok[ext].mean()) if ext.any() else np.nan,
                                  iters_med=float(np.median(ti[inr & ok])) if (inr & ok).any() else np.nan,
                                  iters_mean=float(np.mean(ti[inr & ok])) if (inr & ok).any() else np.nan,
                                  K3_med=float(np.median(mk[inr])), K3_succ=float((mk[inr] < 1e-2).mean()))
    num[prob]["n_in"] = int(inr.sum()); num[prob]["n_ext"] = int(ext.sum()); num[prob]["T_long"] = E["T_long"]
    num[prob]["H"] = E["H"]; num[prob]["N"] = E["N"]; num[prob]["ext"] = E["ext"]
json.dump(num, open("numbers.json", "w"), indent=1)


def f_it(d):
    if d["fail"] >= 1: return r"\multicolumn{1}{c}{--}"
    s = f"{d['median']:.0f}\\,/\\,{d['max']}"
    return s


def pct(x): return f"{100 * x:.0f}"


L = [r"\begin{tabular}{l" + "rr" * 3 + "}", r"\toprule",
     r" & \multicolumn{2}{c}{Duffing} & \multicolumn{2}{c}{van der Pol} & \multicolumn{2}{c}{pendulum} \\",
     r"\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}",
     r"method & its (med/max) & fail \% & its (med/max) & fail \% & its (med/max) & fail \% \\", r"\midrule"]
for m in meths1:
    cells = []
    for prob in ["duffing", "vdp", "pendulum"]:
        d = num[prob]["single"][m]; cells += [f_it(d), pct(d["fail"])]
    L.append(NAMES[m] + " & " + " & ".join(cells) + r" \\")
L += [r"\bottomrule", r"\end{tabular}"]
open("paper2/tab_single.tex", "w").write("\n".join(L) + "\n")

L = [r"\begin{tabular}{l" + "rrr" * 3 + "}", r"\toprule",
     r" & \multicolumn{3}{c}{Duffing} & \multicolumn{3}{c}{van der Pol} & \multicolumn{3}{c}{pendulum} \\",
     r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(lr){8-10}",
     r"method & succ.\ \% & its & $K{=}3$ err & succ.\ \% & its & $K{=}3$ err & succ.\ \% & its & $K{=}3$ err \\", r"\midrule"]


def sci(x):
    if not np.isfinite(x) or x > 1e3: return r"$>10^{3}$"
    e = int(np.floor(np.log10(x))); mnt = x / 10 ** e
    return f"${mnt:.1f}\\cdot 10^{{{e}}}$"


for m in meths2:
    cells = []
    for prob in ["duffing", "vdp", "pendulum"]:
        d = num[prob]["ms"][m]
        cells += [pct(d["succ"]), f"{d['iters_med']:.0f}" if np.isfinite(d["iters_med"]) else "--", sci(d["K3_med"])]
    L.append(NAMES[m] + " & " + " & ".join(cells) + r" \\")
L += [r"\bottomrule", r"\end{tabular}"]
open("paper2/tab_multistage.tex", "w").write("\n".join(L) + "\n")
for prob in num:
    print(prob, "n_in", num[prob]["n_in"], "ext", num[prob]["n_ext"])
    for m, d in num[prob]["single"].items(): print("  S", m, {k: round(v, 3) for k, v in d.items()})
    for m, d in num[prob]["ms"].items(): print("  M", m, {k: (round(v, 3) if v < 1e3 else v) for k, v in d.items()})
