"""Choice of the NODE-VIM switching threshold r_sw (coarse van der Pol grid, mu in [2, 3]); see Section 3.6 of the paper."""
import evalcore
from evalcore import *
torch.set_num_threads(1)
gen, a = load_gen("gen_vdp_H2.00_K4_m2_classical_jri_ph1_s0.pt")
prob = VanDerPol()
ps = np.linspace(2.0, 3.0, 11)
gl = Grid(20.0, 10 * 200); Url, _ = reference(prob, gl, ps); Url = Url[:, 0::2].numpy()
for meth, rsw, kmax in [("hybrid2", None, None), ("hybrid3", None, None), ("learned", None, None), ("adapt", 1e-1, 6), ("adapt", 1e-2, 6), ("adapt", 1e-3, 8)]:
    if rsw: evalcore.ADAPT_RSW, evalcore.ADAPT_KMAX = rsw, kmax
    Ul, _, it = multistage(prob, 2.0, 200, ps, 20.0, meth, gen, tol=1e-7, max_iter=12)
    e = np.abs(Ul - Url).max(1)
    print(f"{meth:8s} rsw={rsw} conv {np.mean(e<1e-4):.2f}  errs " + " ".join(f"{x:.0e}" for x in e) + f"  iters median {np.median(it.sum(1))}")
