"""Ablation metrics for Duffing generators: single-window iteration counts and multistage success."""
import glob, sys
from evalcore import *
torch.set_num_threads(1)
prob = Duffing()
files = sorted(glob.glob("gen_duffing_H2.00_*.pt"))
import os
res = json.load(open("ablation.json")) if os.path.exists("ablation.json") else {}
ps = np.linspace(0.5, 3.0, 26)
grid = Grid(2.0, 200)
Ur, _ = reference(prob, grid, ps)
gl_T = 20.0
gl = Grid(gl_T, 10 * 200)
Url, _ = reference(prob, gl, ps); Url = Url[:, 0::2].numpy()
for f in files:
    if f in res: continue
    gen, a = load_gen(f, prob, grid)
    row = dict(m=a["m"], feats=a["feats"], anchor=a["anchor"], K=a["K"], seed=a["seed"])
    p = torch.tensor(ps)
    for meth in ["learned", "hybrid2", "adapt"]:
        with torch.no_grad():
            gen.grid = grid; gen.prob = prob
            H = run(meth, prob, grid, p, 12, gen)
        E = torch.stack([torch.nan_to_num((U - Ur).abs().amax(1), nan=1e300) for U, V in H])
        it = iters_to(E, 1e-6)
        itc = [i if i >= 0 else 13 for i in it]
        row[meth] = dict(median=float(np.median(itc)), max=int(max(itc)), conv=float(np.mean(np.array(it) >= 0)),
                         err3=float(np.median(E[3].numpy())))
        Ul, _, its = multistage(prob, 2.0, 200, ps, gl_T, meth, gen, tol=1e-7, max_iter=12)
        e = np.abs(Ul - Url).max(1)
        row[meth]["ms_success"] = float(np.mean(e < 1e-4)); row[meth]["ms_iters"] = float(np.median(its.sum(1)))
    tl = json.load(open(f.replace("gen_", "trainlog_").replace(".pt", ".json")))
    row["train_time"] = tl["train_time"]
    res[f] = row
    json.dump(res, open("ablation.json", "w"), indent=1)
    print(f, {k: (v if not isinstance(v, dict) else {kk: round(vv, 3) for kk, vv in v.items()}) for k, v in row.items()}, flush=True)
json.dump(res, open("ablation.json", "w"), indent=1)
