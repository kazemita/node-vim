"""Limitation study: generators trained on H=2 windows used on short windows (H=0.5), multistage to T=20."""
from evalcore import *
torch.set_num_threads(1)
out = {}
for name, files in [("duffing", ["gen_duffing_H2.00_K4_m2_classical_jri_ph1_s0.pt", "gen_duffing_H2.00_K4_m2_classical_sjri_ph1_s0_Hmin0.50.pt"]),
                    ("vdp", ["gen_vdp_H2.00_K4_m2_classical_jri_ph1_s0.pt"])]:
    prob = PROBLEMS[name](); ps = np.linspace(0.5 if name == "duffing" else 0.2, 3.0, 26)
    gl = Grid(20.0, 2000); Url, _ = reference(prob, gl, ps); Url = Url[:, 0::2].numpy()
    res = {}
    for H, N in [(0.5, 50), (2.0, 200)]:
        for tag, meth, f in [("newton", "newton", None)] + [(("adapt_var" if "Hmin" in f else "adapt"), "adapt", f) for f in files]:
            gen = load_gen(f, prob, Grid(H, N))[0] if f else None
            for mode, kw in (("tol", dict(tol=1e-7, max_iter=12)), ("K3", dict(K=3))):
                Ul, _, its = multistage(prob, H, N, ps, 20.0, meth, gen, **kw)
                e = np.nan_to_num(np.abs(Ul - Url).max(1), nan=1e300)
                res[f"H{H}_{mode}_{tag}"] = dict(succ=float(np.mean(e < 1e-4)), err_med=float(np.median(e)),
                                                 iters_med=float(np.median(its.sum(1))))
                print(name, H, mode, tag, {k: round(v, 4) if v < 1e3 else v for k, v in res[f"H{H}_{mode}_{tag}"].items()}, flush=True)
    out[name] = res
json.dump(out, open("short_window.json", "w"), indent=1)
