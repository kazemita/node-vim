"""How many learned steps the adaptive schedule takes per window (single window, cold start) and the
Newton-equivalent cost of NODE-VIM to reach 1e-6."""
from evalcore import *
torch.set_num_threads(1)
cost = json.load(open("cost.json")); out = {}
for name, f, phi in [("duffing", "gen_duffing_H2.00_K4_m2_classical_jri_ph1_s0.pt", 3.0), ("vdp", "gen_vdp_H2.00_K4_m2_classical_jri_ph1_s0.pt", 3.0),
                ("pendulum", "gen_pendulum_H6.00_K4_m2_classical_jri_ph1_s0.pt", 3.0)]:
    prob = PROBLEMS[name](); a = torch.load(f, weights_only=False)["args"]; grid = Grid(a["H"], a["N"])
    gen, _ = load_gen(f, prob, grid)
    E = json.load(open(f"eval_{name}.json")); ps = np.array(E["ps"]); ps = ps[ps <= phi + 1e-9]; p = torch.tensor(ps)
    U, V = initial_guess(prob, grid, p); Acc = -prob.omega0 ** 2 * U
    use = torch.ones(len(ps), dtype=torch.bool); nL = torch.zeros(len(ps))
    with torch.no_grad():
        for n in range(12):
            R = residual_fine(prob, grid, U, V, Acc, p)
            if n > 0: use = use & (R.abs().amax(1) > ADAPT["r_sw"]) & torch.tensor(n < ADAPT["k_max"])
            nL += use.double()
            a0L, a1L, b, q, P = gen(U, V, p, R, n); a0N, a1N = coeffs_fixed("newton", prob, grid, U, V, p); s = use[:, None]
            a0 = torch.where(s, a0L, a0N); a1 = torch.where(s, a1L, a1N); b = torch.where(s[..., None], b, torch.zeros_like(b))
            U, V, dVn, _ = vim_step(prob, grid, U, V, p, a0, a1, b, q, P, return_all=True); Acc = acc_fine(dVn)
    it_a = np.array(E["iters_1e-06"]["adapt"])[:len(ps)]; it_n = np.array(E["iters_1e-06"]["newton"])[:len(ps)]
    c = cost[name]["ratio_learned_newton"]; nL = nL.numpy()
    okb = (it_a >= 0) & (it_n >= 0)
    eq = nL[okb] * c + (it_a[okb] - nL[okb])
    out[name] = dict(nL_median=float(np.median(nL)), nL_max=float(nL.max()), nL_mean=float(nL.mean()),
                     eq_newton_median=float(np.median(eq)), newton_median=float(np.median(it_n[okb])))
    print(name, out[name])
json.dump(out, open("count_learned.json", "w"), indent=1)
