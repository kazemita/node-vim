"""Evaluation helpers: single-window error fields and multistage long-time runs."""
from osc import *
from train import WindowProblem, guess_from_state


def load_gen(path, prob=None, grid=None):
    ck = torch.load(path); a = ck["args"]
    prob = prob or PROBLEMS[a["prob"]]()
    grid = grid or Grid(a["H"], a["N"])
    gen = Generator(prob, grid, (a["plo"], a["phi"]), m=a["m"], anchor=a["anchor"], feats=a["feats"], n_max=a["K"])
    gen.load_state_dict(ck["state"]); gen.eval()
    return gen, a


def iters_to(E, tol):
    """first iteration index with error < tol per column; -1 if never."""
    ok = (E < tol)
    first = torch.where(ok.any(0), ok.float().argmax(0), torch.full((E.shape[1],), -1))
    return first.tolist()


def single_window(prob, grid, ps, methods, gen=None, n_iter=12, store_k=(1, 2, 3, 4)):
    """errors of each method on the window [0, H] with the family's initial condition."""
    p = torch.as_tensor(np.asarray(ps, float))
    Ur, Vr = reference(prob, grid, ps)
    out = {}
    for meth in methods:
        with torch.no_grad():
            if meth == "anderson":
                H = anderson(prob, grid, p, n_iter)
            else:
                g = gen
                if gen is not None: g.grid = grid
                H = run(meth, prob, grid, p, n_iter, g)
        E = torch.stack([torch.nan_to_num((U - Ur).abs().amax(1), nan=1e300) for U, V in H])   # (iters, B)
        fields = {k: torch.nan_to_num((H[k][0] - Ur).abs(), nan=1e300)[:, 0::2].numpy() for k in store_k if k < len(H)}
        out[meth] = dict(E=E.numpy(), fields=fields, U_last=H[min(3, len(H) - 1)][0][:, 0::2].numpy())
    return out, Ur[:, 0::2].numpy(), Vr[:, 0::2].numpy()


ADAPT_RSW, ADAPT_KMAX = 0.1, 6


def multistage(prob, H, N, ps, T_long, method, gen=None, K=3, tol=None, max_iter=12):
    """multistage VIM: windows of length H, K iterations each (or until the window defect < tol)."""
    p = torch.as_tensor(np.asarray(ps, float))
    B = len(ps)
    grid = Grid(H, N)
    wp = WindowProblem(prob)
    if gen is not None: gen.grid = grid; gen.prob = wp
    u0, v0 = prob.ic(p)
    nwin = int(round(T_long / H))
    Us, Vs, iters = [], [], []
    for w in range(nwin):
        wp.u0, wp.v0 = u0, v0
        U, V = guess_from_state(prob, grid, u0, v0)
        Acc = -prob.omega0 ** 2 * U
        n_used = torch.zeros(B, dtype=torch.long)
        k_switch = None
        meth = method
        adaptive = method.startswith("adapt")            # learned until max defect < r_sw (at most k_max), then Newton
        if method.startswith("hybrid"): k_switch = int(method[6:]); meth = "learned"
        if adaptive: meth = "learned"; k_switch = 99
        use_learned = torch.ones(B, dtype=torch.bool)
        active = torch.ones(B, dtype=torch.bool)
        for n in range(K if tol is None else max_iter):
            with torch.no_grad():
                if adaptive and n > 0:
                    Rmax = residual_fine(wp, grid, U, V, Acc, p).abs().amax(1)
                    use_learned = use_learned & (Rmax > ADAPT_RSW) & (n < ADAPT_KMAX)
                if adaptive:
                    R = residual_fine(wp, grid, U, V, Acc, p)
                    a0L, a1L, b, q, P = gen(U, V, p, R, n)
                    a0N, a1N = coeffs_fixed("newton", wp, grid, U, V, p)
                    sel = use_learned[:, None]
                    a0 = torch.where(sel, a0L, a0N); a1 = torch.where(sel, a1L, a1N)
                    if b is not None:
                        b = torch.where(sel[..., None], b, torch.zeros_like(b))
                    Un, Vn, dVn, _ = vim_step(wp, grid, U, V, p, a0, a1, b, q, P, return_all=True)
                elif meth == "learned" and (k_switch is None or n < k_switch):
                    R = residual_fine(wp, grid, U, V, Acc, p)
                    a0, a1, b, q, P = gen(U, V, p, R, n)
                    Un, Vn, dVn, _ = vim_step(wp, grid, U, V, p, a0, a1, b, q, P, return_all=True)
                else:
                    mm = "newton" if k_switch is not None else meth
                    a0, a1 = coeffs_fixed(mm, wp, grid, U, V, p)
                    Un, Vn, dVn, _ = vim_step(wp, grid, U, V, p, a0, a1, return_all=True)
            Un = torch.nan_to_num(Un, nan=1e6).clamp(-1e6, 1e6); Vn = torch.nan_to_num(Vn, nan=1e6).clamp(-1e6, 1e6)
            dVn = torch.nan_to_num(dVn, nan=1e6).clamp(-1e12, 1e12)
            if tol is not None:
                upd = active
                U = torch.where(upd[:, None], Un, U); V = torch.where(upd[:, None], Vn, V)
                Acc = torch.where(upd[:, None], acc_fine(dVn), Acc)
                n_used += upd.long()
                Rn = residual_nodes(wp, grid, U, V, dVn, p).abs().amax(1)
                active = active & (Rn > tol)
                if not active.any(): break
            else:
                U, V, Acc = Un, Vn, acc_fine(dVn); n_used += 1
        Us.append(U[:, 0::2] if w == 0 else U[:, 2::2]); Vs.append(V[:, 0::2] if w == 0 else V[:, 2::2])
        iters.append(n_used.numpy())
        u0, v0 = U[:, -1].clone(), V[:, -1].clone()
    Ul = torch.cat(Us, 1).numpy(); Vl = torch.cat(Vs, 1).numpy()
    return Ul, Vl, np.stack(iters, 1)
