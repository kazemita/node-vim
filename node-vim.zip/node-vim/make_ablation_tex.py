"""Ablation table (LaTeX) from ablation.json, with Newton on the same 26 amplitudes as a reference row."""
import json, numpy as np
r = json.load(open("ablation.json"))
E = json.load(open("eval_duffing.json")); ps = np.array(E["ps"]); sel = np.isin(np.round(ps, 4), np.round(np.linspace(0.5, 3.0, 26), 4))
it = np.array(E["iters_1e-06"]["newton"])[sel]; me = np.nan_to_num(np.array(E["multistage"]["tol_newton"]["maxerr"], float), nan=1e300)[sel]
ti = np.array(E["multistage"]["tol_newton"]["total_iters"], float)[sel]
newton = dict(median=float(np.median(it[it >= 0])), max=int(it[it >= 0].max()), succ=float(np.mean(me < 1e-4)), its=float(np.median(ti[me < 1e-4])))
P = "gen_duffing_H2.00_"
rows = [("main: $m=2$, features $j,r,i$, classical anchor, $K=4$", "K4_m2_classical_jri_ph1_s0.pt"),
        ("$m=0$ (no latent memory)", "K4_m0_classical_jri_ph1_s0.pt"),
        ("$m=4$", "K4_m4_classical_jri_ph1_s0.pt"),
        ("features $j$ only", "K4_m2_classical_j_ph1_s0.pt"),
        ("features $j,r$", "K4_m2_classical_jr_ph1_s0.pt"),
        ("features $j,i$", "K4_m2_classical_ji_ph1_s0.pt"),
        ("features $r,i$ (no Jacobians)", "K4_m2_classical_ri_ph1_s0.pt"),
        ("Newton anchor", "K4_m2_newton_jri_ph1_s0.pt"),
        ("defect-gated anchor", "K4_m2_gated_jri_ph1_s0.pt"),
        ("unroll $K=2$", "K2_m2_classical_jri_ph1_s0.pt"),
        ("seed 1", "K4_m2_classical_jri_ph1_s1.pt"),
        ("seed 2", "K4_m2_classical_jri_ph1_s2.pt"),
        ("random window length $H\\in[0.5,2]$", "K4_m2_classical_sjri_ph1_s0_Hmin0.50.pt")]
L = [r"\begin{tabular}{lrrrrrr}", r"\toprule",
     r" & \multicolumn{3}{c}{learned only} & \multicolumn{3}{c}{NODE-VIM} \\",
     r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}",
     r"variant & its (med/max) & succ.\ \% & its & its (med/max) & succ.\ \% & its \\", r"\midrule"]
summary = {}
for lab, f in rows:
    if P + f not in r: continue
    x = r[P + f]; l, a = x["learned"], x["adapt"]
    summary[lab] = dict(learned=l, adapt=a)
    L.append(f"{lab} & {l['median']:.1f}\\,/\\,{l['max']} & {100*l['ms_success']:.0f} & {l['ms_iters']:.1f} & "
             f"{a['median']:.1f}\\,/\\,{a['max']} & {100*a['ms_success']:.0f} & {a['ms_iters']:.1f} \\\\")
L.append(r"\midrule")
L.append(f"Newton (reference) & \\multicolumn{{3}}{{c}}{{--}} & {newton['median']:.1f}\\,/\\,{newton['max']} & {100*newton['succ']:.0f} & {newton['its']:.1f} \\\\")
L += [r"\bottomrule", r"\end{tabular}"]
open("paper2/tab_ablation.tex", "w").write("\n".join(L) + "\n")
json.dump(dict(rows=summary, newton=newton), open("ablation_summary.json", "w"), indent=1)
print("\n".join(L))
