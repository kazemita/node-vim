"""Main evaluation for one problem: single-window error fields (contours in (t, p)), iteration counts,
multistage long-time runs (solution / error / iteration fields), period estimates.
usage: python evaluate_all.py <generator.pt> <T_long>"""
import sys
from evalcore import *
torch.set_num_threads(1)

path, T_long = sys.argv[1], float(sys.argv[2])
gen, a = load_gen(path)
prob = PROBLEMS[a["prob"]]()
H, N = a["H"], a["N"]
grid = Grid(H, N)
plo, phi = a["plo"], a["phi"]
ext = {"duffing": 3.5, "vdp": 3.5, "pendulum": 3.1}[a["prob"]]
ps = np.round(np.linspace(plo, ext, 61), 4)
methods = ["classical", "freqadj", "newton", "anderson", "learned", "hybrid1", "hybrid2", "hybrid3", "adapt"]
out = dict(args=a, ps=ps.tolist(), H=H, N=N, T_long=T_long, ext=ext)

# ---------------- single window, family initial condition ----------------
t0 = time.time()
gen.prob = prob
sw, Ur, Vr = single_window(prob, grid, ps, methods, gen, n_iter=12)
out["single"] = {m: dict(E=v["E"].tolist()) for m, v in sw.items()}
np.savez_compressed(f"sw_{a['prob']}.npz", t=grid.tn.numpy(), ps=ps, Ur=Ur, Vr=Vr,
                    **{f"{m}_k{k}": f for m, v in sw.items() for k, f in v["fields"].items()},
                    **{f"{m}_U3": v["U_last"] for m, v in sw.items()})
for tol in (1e-3, 1e-6):
    out[f"iters_{tol:.0e}"] = {m: iters_to(torch.tensor(v["E"]), tol) for m, v in sw.items()}
print(f"single window done ({time.time()-t0:.0f}s)", flush=True)
for m in methods:
    it = out["iters_1e-06"][m]
    print(f"  {m:10s} iters->1e-6 (p in train range): median {np.median([i if i >= 0 else 99 for i, p in zip(it, ps) if p <= phi])}"
          f"  max {max([i if i >= 0 else 99 for i, p in zip(it, ps) if p <= phi])}", flush=True)

# ---------------- multistage, long time ----------------
t0 = time.time()
Nl = int(round(T_long / H)) * N
gl = Grid(T_long, Nl)
Url, Vrl = reference(prob, gl, ps)
Url, Vrl = Url[:, 0::2].numpy(), Vrl[:, 0::2].numpy()
ms = {}
fields = dict(t=gl.tn.numpy(), ps=ps, U=Url, V=Vrl)
for mode, kw in (("tol", dict(tol=1e-7, max_iter=12)), ("K3", dict(K=3))):
    for m in ["classical", "freqadj", "newton", "learned", "hybrid2", "adapt"]:
        gen.prob = prob
        Ul, Vl, it = multistage(prob, H, N, ps, T_long, m, gen, **kw)
        err = np.abs(Ul - Url)
        fields[f"{mode}_{m}_err"] = err.astype(np.float32)
        fields[f"{mode}_{m}_U"] = Ul.astype(np.float32)
        fields[f"{mode}_{m}_V"] = Vl.astype(np.float32)
        fields[f"{mode}_{m}_it"] = it
        ms[f"{mode}_{m}"] = dict(maxerr=err.max(1).tolist(), total_iters=it.sum(1).tolist())
        print(f"  multistage {mode:3s} {m:9s} maxerr median {np.median(err.max(1)):.1e}  "
              f"converged(<1e-4) {np.mean(err.max(1) < 1e-4)*100:.0f}%  total iters median {np.median(it.sum(1)):.0f}", flush=True)
np.savez_compressed(f"ms_{a['prob']}.npz", **fields)
out["multistage"] = ms
print(f"multistage done ({time.time()-t0:.0f}s)", flush=True)
json.dump(out, open(f"eval_{a['prob']}.json", "w"))
